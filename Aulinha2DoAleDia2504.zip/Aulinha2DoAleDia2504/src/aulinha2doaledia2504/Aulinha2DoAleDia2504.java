/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aulinha2doaledia2504;

import javax.swing.JOptionPane;

/**
 *
 * @author paulo.hsferreira8
 */
public class Aulinha2DoAleDia2504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
 int opcao = JOptionPane.showConfirmDialog(null,"Voce trabalha?");
        if (opcao == 0) {
         JOptionPane.showMessageDialog(null,"Parabéns");   
        }
        else if (opcao == 1) {
        JOptionPane.showMessageDialog(null,"Ta na hora ne vagabundo");       
        }
        else if (opcao == 2) {
          JOptionPane.showMessageDialog(null,"que pena  ");         
        }
        
        
    }
    
}
